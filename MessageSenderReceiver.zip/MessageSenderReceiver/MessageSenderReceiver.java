package MessageSenderReceiver;

public class MessageSenderReceiver {

    public static void main(String[] args) {

        Sender sender = new Sender("Sender");
        Receiver receiver = new Receiver("Receiver");
        MessageImpl impl = new MessageImpl();
        impl.messageInfo(sender, receiver);

    }
}
