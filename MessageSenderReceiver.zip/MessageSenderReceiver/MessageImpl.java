package MessageSenderReceiver;

import java.util.HashMap;
import java.util.Map;

public class MessageImpl {

    Map<String, Integer> counterResult = new HashMap<>();
    int counter = 1;

    public void messageInfo(Sender sender, Receiver receiver) {
        for (int i = 0; i < 15; i++) {
            if (counter == 6) {
                System.exit(0);
            }
            String message = "Hi, This is my message " + counter;
            sender.setMessage(message);
            System.out.println("Sender Message: " + sender.getMessage());
            receivedMessage(sender, receiver, counter);
        }
    }


    public void receivedMessage(Sender sender, Receiver receiver, int messageCount) {
        String receiveMessage = "Yes Received message " + messageCount + " from Sender";
        String sentBackMessage = sender.getMessage() + " for count-" + messageCount;
        System.out.println("Receiver Message: " + receiveMessage);
        System.out.println("Sender Back Message: " + sentBackMessage);
        counter++;


    }
}
