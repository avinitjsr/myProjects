package MessageSenderReceiver;



public class Sender {
    
    String name ;
    String message;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Sender(String name){
        this.name=name;
    }


   /* public static void main(String [] args){
        // get the initial context
        InitialContext context = new InitialContext();

        // lookup the queue object
        Queue queue = (Queue) context.lookup("queue/queue0");

        // lookup the queue connection factory
        QueueConnectionFactory conFactory = (QueueConnectionFactory) context.lookup ("queue/connectionFactory");

        // create a queue connection
        QueueConnection queConn = conFactory.createQueueConnection();

        // create a queue session
        QueueSession queSession = queConn.createQueueSession(false, Session.DUPS_OK_ACKNOWLEDGE);

        // create a queue sender
        QueueSender queSender = queSession.createSender(queue);
        queueSender.setDeliveryMode(DeliveryMode.NON_PERSISTENT);

        // create a simple message to say "Hello World"
        TextMessage message = queSession.createTextMessage("Hello World");

        // send the message
        queSender.send(message);

        // print what we did
        System.out.println("Message Sent: " + message.getText());

        // close the queue connection
        queConn.close();
    }*/
}
