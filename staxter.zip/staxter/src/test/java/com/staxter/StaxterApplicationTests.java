package com.staxter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StaxterApplicationTests {

	@Test
	void contextLoads() {
	}

}
