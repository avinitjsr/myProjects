package com.staxter.controller;

import com.staxter.model.RegistrationReqData;
import com.staxter.userrepository.User;
import com.staxter.userrepository.UserRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.Assert.assertEquals;

/**
 * <h1>UserServiceControllerTest</h1>
 * UserServiceControllerTest use for Unit test for UserServiceController
 */
@RunWith(SpringRunner.class)
@WebMvcTest(value = UserServiceController.class)
public class UserServiceControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserRepository userRepository;

    /**
     * registrationProcessTest method use for unit test for registrationProcess method of UserServiceController
     * If registration successfull
     * Mock verifyUserName and createUser method for userRepository service
     * @throws Exception
     */
    @Test
    public void registrationProcessTest() throws Exception {
        RegistrationReqData reqData = new RegistrationReqData();
        reqData.setFirstName("avi");
        reqData.setLastName("kumar");
        reqData.setPassword("avinash");
        reqData.setUserName("avi1");


        String reqJSON = "{\"firstName\": \"avinash\",\"lastName\": \"kumar\",\"userName\": \"avi1\",\"password\": \"avinash\"}";
        Mockito.when(
                userRepository.verifyUserName(Mockito.anyString())).thenReturn("Success");
        User user = new User(reqData.getFirstName(), reqData.getLastName(), reqData.getUserName(), reqData.getPassword());
        Mockito.when(
                userRepository.createUser(Mockito.any(User.class))).thenReturn(user);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/userservice/register")
                .content(reqJSON).contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        int response = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), response);


    }

    /**
     * registrationProcessTest method use for unit test for registrationProcess method of UserServiceController
     * If user exist error-code 409
     * Mock verifyUserName and createUser method for userRepository service
     * @throws Exception
     */
    @Test
    public void registrationProcessExceptionTest() throws Exception {

        String reqJSON = "{\"firstName\": \"avinash\",\"lastName\": \"kumar\",\"userName\": \"avi1\",\"password\": \"avinash\"}";
        Mockito.when(
                userRepository.verifyUserName(Mockito.anyString())).thenReturn("Failure");

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/userservice/register")
                .content(reqJSON).contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        int response = result.getResponse().getStatus();
        assertEquals(HttpStatus.CONFLICT.value(), response);


    }

    /**
     * loginTest method use for unit test for login method of UserServiceController
     * @throws Exception
     */
    @Test
    public void loginTest() throws Exception {
        Mockito.when(
                userRepository.loginDetails(Mockito.anyString(), Mockito.anyString())).thenReturn("Success");
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/userservice/login/default/default").accept(
                MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        int response = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), response);
    }
}
