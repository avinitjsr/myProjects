package com.staxter.error;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * <h1>UserAlreadyExistException</h1>
 * The UserAlreadyExistException use for allready exist user
 */
@ResponseStatus(HttpStatus.CONFLICT)
public class UserAlreadyExistException extends RuntimeException {
    /**
     * UserAlreadyExistException constructor
     * @param message
     */
    public UserAlreadyExistException(String message){
            super(message);
    }
}
