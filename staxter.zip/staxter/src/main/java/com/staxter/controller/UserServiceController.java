package com.staxter.controller;

import com.staxter.error.UserAlreadyExistException;
import com.staxter.model.RegistrationReqData;
import com.staxter.model.RegistrationResData;
import com.staxter.services.UserRepositoryImpl;
import com.staxter.userrepository.User;
import com.staxter.userrepository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;

@RestController
public class UserServiceController {

    @Autowired
    private UserRepositoryImpl service;

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/test")
    public RegistrationResData myTest(){
        return new RegistrationResData("1","avinash","kumar","avi");
    }

    @PostMapping("/userservice/register")
    public RegistrationResData registrationProcess(@RequestBody RegistrationReqData registrationReqData) throws UserAlreadyExistException {
        String firstName=registrationReqData.getFirstName();
        String lastName=registrationReqData.getLastName();
        String userName=registrationReqData.getUserName();
        String password=registrationReqData.getPassword();

        String result=userRepository.verifyUserName(userName);
        if(null!=result && result.equalsIgnoreCase("Failure")){

             throw new UserAlreadyExistException(result);
        }

        User user=new User(firstName,lastName,userName,password);
        User userCreated=userRepository.createUser(user);
        String id=userCreated.getId();

        return new RegistrationResData(id,firstName,lastName,userName);
    }
}
