package com.staxter.controller;

import com.staxter.error.UserAlreadyExistException;
import com.staxter.model.RegistrationReqData;
import com.staxter.model.RegistrationResData;
import com.staxter.userrepository.User;
import com.staxter.userrepository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <h1>UserServiceController</h1>
 * The UserServiceController is RestController
 * for Registration and Login
 */
@RestController
public class UserServiceController {


    @Autowired
    private UserRepository userRepository;

    /**
     * login method use for login userservice
     * @param userName This is first parameter for login
     * @param password This is second parameter for login
     * @return String  This returns succesfull or failure login details
     */
    @GetMapping("/userservice/login/{userName}/{password}")
    public String login(@PathVariable String userName, @PathVariable String password) {

        String result = userRepository.loginDetails(userName, password);
        return result;
    }

    /**
     * registrationProcess method  use for resister the userservice
     * @param registrationReqData This takes registrationReqData as JSON format for registration
     * @return RegistrationResData After successfully registration returns RegistrationResData with userDetails
     * @throws UserAlreadyExistException If User already exist throw the exception with error-code 409.
     */
    @PostMapping("/userservice/register")
    public RegistrationResData registrationProcess(@RequestBody RegistrationReqData registrationReqData) throws UserAlreadyExistException {
        String firstName = registrationReqData.getFirstName();
        String lastName = registrationReqData.getLastName();
        String userName = registrationReqData.getUserName();
        String password = registrationReqData.getPassword();

        String result = userRepository.verifyUserName(userName);
        if (null != result && result.equalsIgnoreCase("Failure")) {

            throw new UserAlreadyExistException(result);
        }

        User user = new User(firstName, lastName, userName, password);
        User userCreated = userRepository.createUser(user);
        String id = userCreated.getId();

        return new RegistrationResData(id, firstName, lastName, userName);
    }
}
