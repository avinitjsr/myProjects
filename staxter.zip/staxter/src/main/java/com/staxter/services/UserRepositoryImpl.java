package com.staxter.services;

import com.staxter.userrepository.User;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class UserRepositoryImpl {

    private static int userCount=0;

    private static List<User> users=new ArrayList<>();

    public User createUser(User user){
        if(user.getId()==null){
            user.setId(String.valueOf(++userCount));
        }
        users.add(user);
        return user;
    }

    public String verifyUserName(String userName){
        for(User user: users) {
            if (user.getUserName().equalsIgnoreCase(userName)) {
                    return "Failure";
            }

        }
        return "Success";
    }

}
