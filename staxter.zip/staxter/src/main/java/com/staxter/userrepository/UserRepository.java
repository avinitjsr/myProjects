package com.staxter.userrepository;

import com.staxter.error.UserAlreadyExistException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, String> {

    User createUser(User user) throws UserAlreadyExistException;

    String verifyUserName(String userName);
}
